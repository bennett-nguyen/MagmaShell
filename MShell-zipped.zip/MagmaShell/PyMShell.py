import sys
import os

sys.path.append(os.path.join(os.getcwd(), "utils"))
sys.path.append(os.path.join(os.getcwd(), "built_in_cmds"))

from built_in_cmds.register import registered_cmds

def process(user_in):
    cmd = user_in.split(" ")
    
    registered_cmds[cmd[0]]() if cmd[0] in registered_cmds else print(f"Command not found.")

        
	

	
