import utils
import os

path_cmds_dict = {}

@utils.register(path_cmds_dict)
def pwd():
    print(os.getcwd())
