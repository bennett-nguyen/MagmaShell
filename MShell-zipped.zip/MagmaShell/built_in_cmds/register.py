import os_cmd, path_cmd

registered_cmds = {**os_cmd.os_cmds_dict, **path_cmd.path_cmds_dict}



