from .String import Str
from .Integer import Int
from .Float import Float
from .Bool import Bool