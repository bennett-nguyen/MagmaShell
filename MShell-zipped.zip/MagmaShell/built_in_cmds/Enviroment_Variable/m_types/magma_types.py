class Type:
    __magma_types = {
        "Str": str,
        "Int": int,
        "Float": float,
        "Bool": bool
    }
	
    def __init__(self, name: str, value: str, value_type: str, is_constant: str) -> None:
        try:
			__magma_types[value_type](value)
        except:
            raise TypeError(f"Invalid type <{value_type}> for the given value <{value}>.")
		else:
			self.name = name
            self.value = __magma_types[value_type](value)
            self.value_type = value_type
            self.is_constant = is_constant

    def __repr__(self):
        return f"<Object <<{self.value_type}>> __name: {self.name}__ __value: {self.value}__ __is_const: {self.is_constant}__> at {hex(id(self))}"
		
    def __str__(self):
        return self.value
