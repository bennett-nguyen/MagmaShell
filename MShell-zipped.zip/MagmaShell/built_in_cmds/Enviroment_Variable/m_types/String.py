from magma_types import Type

class Str(Type):
    def __init__(self, name: str, value: str, value_type: str, is_constant: str) -> None:
        super().__init__(name, value, value_type, is_constant)

