import utils
import os
from sys import platform
os_cmds_dict = {}


@utils.register(os_cmds_dict)
def exit():
    raise Exception

@utils.register(os_cmds_dict)
def ls():
    for i in os.listdir("./"):
        print(i)

@utils.register(os_cmds_dict)
def clear():
    if platform in ["linux", "linux2", "darwin"]:
        os.system("clear")
    else:
        os.system("cls")
        





