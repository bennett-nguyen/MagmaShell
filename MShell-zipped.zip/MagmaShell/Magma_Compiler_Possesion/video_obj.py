class Image:
    def __init__(self, PATH: str, RESULT_NAME: str, ASCII_CHAR: list, INVERTED_RENDERING: bool, WRITE_INFO: bool) -> None:
        self.PATH = PATH
        self.NAME = PATH.split("\\")[-1]
        self.RESULT_NAME = RESULT_NAME
        self.ASCII_CHAR = ASCII_CHAR
        self.INVERTED_RENDERING = INVERTED_RENDERING
        self.WRITE_INFO = WRITE_INFO

class Video(Image):
    def __init__(self, PATH: str, ASCII_CHAR: list, KEEP_RAW: bool, FRAME_SKIP: bool, KEEP_AUDIO: bool, INVERTED_RENDERING: bool, WRITE_INFO: bool):
        super().__init__(PATH, RESULT_NAME, ASCII_CHAR, INVERTED_RENDERING, WRITE_INFO)
        self.KEEP_RAW = KEEP_RAW
        self.KEEP_AUDIO = KEEP_AUDIO
        self.FRAME_SKIP = FRAME_SKIP

