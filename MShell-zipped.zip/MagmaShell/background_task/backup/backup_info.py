import json

backup_json_object = {}

backup_json_object["shell_config"] = {
        "JSON_CONFIG": None,
        "ENVIROMENT_VAR": None
}

backup_json_object["compiler_config"] = {
	"INPUT_DIRECTORY": None,
	"OUTPUT_DIRECTORY": None
}

backup_json_object["video_config"] = {
       	"ASCII_CHAR": [".", ",", ":", ";", "+","*", "?", "%", "S", "#", "@"], 
	"PATH": None,
	"RESULT_NAME": None, 
	"INVERTED_RENDERING": False,
    	"FRAME_SKIP": 3,
    	"KEEP_RAW": False,
    	"KEEP_AUDIO": True,		        "WRITE_INFO": True
}

backup_json_object["image_config"] = {
     	"ASCII_CHAR": [".", ",", 		":", ";", "+","*", "?", "%", "S", "#", "@"], 
	"PATH": None,
	"RESULT_NAME": None, 
	"INVERTED_RENDERING": False,
        "WRITE_INFO": True
}

backup_json_object["displayer_config"] = {
        "FPS": 60
}

with open("random_boilerplate_path.json", "w") as f:
    json.dump(f, backup_json_object, indent = 4)

