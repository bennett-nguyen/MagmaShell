def register(registered_cmds):
	def decorator(function):
		registered_cmds.update({function.__name__: function})
		def wrapper(*args, **kwargs):
			return function(*args, **kwargs)
		return wrapper
	return decorator
