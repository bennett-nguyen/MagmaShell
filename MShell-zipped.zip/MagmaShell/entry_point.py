from PyMShell import process

try:
    while True:
        user_input = input("?> ")
        process(user_input)
except KeyboardInterrupt:
    print("\nExited the program.")
except Exception:
    print("Process died.")
